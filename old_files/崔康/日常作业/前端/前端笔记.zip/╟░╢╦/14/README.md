# 课程介绍

学习前后台数据交互ajax和jsonp，正则表达式和表单验证，jqueryUI插件等。